const API_KEY = "0440b18dfac7fce86bb5ea2c7e64a27d";
const BASE_URL = "https://api.openweathermap.org/data/2.5";

const PERSIAN_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

const WIND_DIRECTIONS = [
  "شمالی",
  "شمال شرقی",
  "شرقی",
  "جنوب شرقی",
  "جنوبی",
  "جنوب غربی",
  "غربی",
  "شمال غربی",
];

const THEME_MAP = {
  Clear: "clear",
  Clouds: "clouds",
  Rain: "rain",
  Drizzle: "drizzle",
  Snow: "snow",
  Thunderstorm: "thunderstorm",
  Mist: "mist",
  Smoke: "mist",
  Haze: "mist",
  Dust: "mist",
  Fog: "mist",
  Sand: "mist",
  Ash: "mist",
  Squall: "rain",
  Tornado: "thunderstorm",
};

const WEATHER_FA = {
  200: "رعد و برق با باران سبک",
  201: "رعد و برق با باران",
  202: "رعد و برق با باران شدید",
  210: "رعد و برق خفیف",
  211: "رعد و برق",
  212: "رعد و برق شدید",
  221: "رعد و برق پراکنده",
  230: "رعد و برق با نم‌نم باران",
  231: "رعد و برق با باران ریز",
  232: "رعد و برق با باران ریز شدید",
  300: "نم‌نم باران",
  301: "باران ریز",
  302: "باران ریز شدید",
  310: "نم‌نم باران سبک",
  311: "باران ریز",
  312: "باران ریز شدید",
  313: "رگبار و نم‌نم باران",
  314: "رگبار شدید",
  321: "رگبار نم‌نم باران",
  500: "باران سبک",
  501: "باران",
  502: "باران شدید",
  503: "باران بسیار شدید",
  504: "سیل",
  511: "باران یخ‌زده",
  520: "رگبار سبک",
  521: "رگبار",
  522: "رگبار شدید",
  531: "رگبار پراکنده",
  600: "برف سبک",
  601: "برف",
  602: "برف سنگین",
  611: "تگرگ",
  612: "رگبار تگرگ",
  613: "رگبار تگرگ شدید",
  615: "باران و برف",
  616: "باران و برف",
  620: "رگبار برف سبک",
  621: "رگبار برف",
  622: "رگبار برف شدید",
  701: "مه",
  711: "دود",
  721: "غبار",
  731: "طوفان شن",
  741: "مه غلیظ",
  751: "شن",
  761: "گرد و خاک",
  762: "خاکستر آتشفشان",
  771: "تندباد",
  781: "گردباد",
  800: "آسمان صاف",
  801: "کمی ابری",
  802: "نیمه ابری",
  803: "عمدتاً ابری",
  804: "ابری",
};

const AQI_LABELS = ["", "خوب", "قابل قبول", "متوسط", "ناسالم", "بسیار ناسالم"];

const AQI_CLASSES = [
  "",
  "aqi-good",
  "aqi-fair",
  "aqi-moderate",
  "aqi-poor",
  "aqi-very-poor",
];

const GEO_ERRORS = {
  1: "دسترسی به موقعیت مکانی رد شد",
  2: "موقعیت مکانی در دسترس نیست",
  3: "مهلت دریافت موقعیت تمام شد",
};

const DEBUG_WEATHER_MAP = {
  "clear-day": ["Clear", "01d"],
  "clear-night": ["Clear", "01n"],
  "clouds-day": ["Clouds", "04d"],
  "clouds-night": ["Clouds", "04n"],
  "rain-day": ["Rain", "10d"],
  "rain-night": ["Rain", "10n"],
  "thunder-day": ["Thunderstorm", "11d"],
  "thunder-night": ["Thunderstorm", "11n"],
  "snow-day": ["Snow", "13d"],
  "snow-night": ["Snow", "13n"],
  "mist-day": ["Mist", "50d"],
  "mist-night": ["Mist", "50n"],
};

function toPersianNumber(num) {
  return String(num)
    .replace("-", "\u200E-")
    .replace(/\d/g, (d) => PERSIAN_DIGITS[d]);
}

function getWindDirection(deg) {
  return WIND_DIRECTIONS[Math.round(deg / 45) % 8];
}

function formatTime(timestamp, timezone) {
  const date = new Date((timestamp + timezone) * 1000);
  const h = date.getUTCHours().toString().padStart(2, "0");
  const m = date.getUTCMinutes().toString().padStart(2, "0");
  return toPersianNumber(`${h}:${m}`);
}

function formatPersianDate(timestamp, timezone) {
  const date = new Date((timestamp + timezone) * 1000);
  return date.toLocaleDateString("fa-IR", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "UTC",
  });
}

function calcDewPoint(tempC, humidity) {
  const a = 17.27;
  const b = 237.7;
  const alpha = (a * tempC) / (b + tempC) + Math.log(humidity / 100);
  return Math.round((b * alpha) / (a - alpha));
}

function getIconUrl(code, size = 2) {
  return `https://openweathermap.org/img/wn/${code}@${size}x.png`;
}

function tempToColor(temp, min, max) {
  const ratio = Math.max(0, Math.min(1, (temp - min) / (max - min || 1)));
  const stops = [
    [96, 165, 250],
    [250, 204, 21],
    [239, 68, 68],
  ];
  const idx = ratio <= 0.5 ? 0 : 1;
  const t = ratio <= 0.5 ? ratio * 2 : (ratio - 0.5) * 2;
  const from = stops[idx];
  const to = stops[idx + 1];
  const mix = (i) => Math.round(from[i] + (to[i] - from[i]) * t);
  return `rgb(${mix(0)},${mix(1)},${mix(2)})`;
}

class RequestCache {
  constructor(ttl = 600000) {
    this.ttl = ttl;
    this.store = new Map();
  }

  get(key) {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() - entry.time > this.ttl) {
      this.store.delete(key);
      return null;
    }
    return entry.data;
  }

  set(key, data) {
    this.store.set(key, { data, time: Date.now() });
  }
}

class ParticleSystem {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.particles = [];
    this.type = null;
    this.animId = null;
    this.lightningTimer = 0;
    this.lightningBolt = null;
    this.lightningCooldown = 0;
    this.shootingStars = [];
    this.shootingCooldown = 0;
    this.resize();
    window.addEventListener("resize", () => this.resize());
  }

  resize() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  resolveParticleType(weatherMain, night) {
    const map = {
      Thunderstorm: "thunder",
      Rain: "rain",
      Drizzle: "rain",
      Squall: "rain",
      Snow: "snow",
      Clouds: "cloudy",
      Mist: "mist",
      Fog: "mist",
      Haze: "mist",
      Smoke: "mist",
      Dust: "mist",
      Sand: "mist",
      Ash: "mist",
    };
    if (weatherMain === "Clear") return night ? "stars" : "sun";
    return map[weatherMain] || null;
  }

  setWeather(weatherMain, iconCode) {
    const type = this.resolveParticleType(weatherMain, iconCode.endsWith("n"));

    if (type === this.type) return;
    this.type = type;
    this.particles = [];
    this.lightningTimer = 0;
    this.lightningBolt = null;
    this.lightningCooldown = 0;
    this.shootingStars = [];
    this.shootingCooldown = 0;

    if (this.animId) {
      cancelAnimationFrame(this.animId);
      this.animId = null;
    }

    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    if (!type) return;
    this.initParticles();
    this.animate();
  }

  initParticles() {
    const w = this.canvas.width;
    const h = this.canvas.height;

    if (this.type === "rain") {
      for (let i = 0; i < 120; i++) {
        this.particles.push({
          x: Math.random() * w * 1.2,
          y: Math.random() * h,
          len: 10 + Math.random() * 20,
          speed: 8 + Math.random() * 10,
          opacity: 0.1 + Math.random() * 0.2,
          wind: -0.8 - Math.random() * 1.5,
        });
      }
    } else if (this.type === "thunder") {
      for (let i = 0; i < 280; i++) {
        this.particles.push({
          x: Math.random() * w * 1.4,
          y: Math.random() * h,
          len: 14 + Math.random() * 28,
          speed: 10 + Math.random() * 14,
          opacity: 0.12 + Math.random() * 0.25,
          wind: -3 - Math.random() * 2.5,
        });
      }
    } else if (this.type === "snow") {
      for (let i = 0; i < 100; i++) {
        const isCrystal = Math.random() < 0.35;
        this.particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          r: isCrystal ? 3 + Math.random() * 5 : 1 + Math.random() * 2.5,
          speed: isCrystal
            ? 0.3 + Math.random() * 0.6
            : 0.5 + Math.random() * 1.2,
          phase: Math.random() * Math.PI * 2,
          amplitude: 0.3 + Math.random() * 0.8,
          opacity: isCrystal
            ? 0.5 + Math.random() * 0.4
            : 0.15 + Math.random() * 0.35,
          crystal: isCrystal,
          rotation: Math.random() * Math.PI * 2,
          rotSpeed: (Math.random() - 0.5) * 0.008,
        });
      }
    } else if (this.type === "stars") {
      for (let i = 0; i < 30; i++) {
        this.particles.push({
          x: Math.random() * w,
          y: Math.random() * h * 0.65,
          r: 2 + Math.random() * 2.5,
          baseOpacity: 0.6 + Math.random() * 0.4,
          phase: Math.random() * Math.PI * 2,
          speed: 0.3 + Math.random() * 0.5,
          bright: true,
        });
      }
      for (let i = 0; i < 120; i++) {
        this.particles.push({
          x: Math.random() * w,
          y: Math.random() * h * 0.75,
          r: 0.4 + Math.random() * 1.2,
          baseOpacity: 0.2 + Math.random() * 0.4,
          phase: Math.random() * Math.PI * 2,
          speed: 0.2 + Math.random() * 0.8,
          bright: false,
        });
      }
    } else if (this.type === "sun") {
      for (let i = 0; i < 35; i++) {
        this.particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          r: 2 + Math.random() * 4,
          speed: 0.15 + Math.random() * 0.35,
          opacity: 0.06 + Math.random() * 0.1,
          phase: Math.random() * Math.PI * 2,
        });
      }
    } else if (this.type === "cloudy") {
      for (let i = 0; i < 8; i++) {
        const cw = Math.ceil(280 + Math.random() * 320);
        const ch = Math.ceil(cw * (0.35 + Math.random() * 0.18));
        const depth = 0.35 + Math.random() * 0.65;
        const texture = this.generateCloudTexture(cw, ch, depth);
        this.particles.push({
          x: Math.random() * w,
          y: 10 + Math.random() * h * 0.5,
          width: cw,
          height: ch,
          speed: 0.15 + Math.random() * 0.3,
          depth,
          texture,
          phase: Math.random() * Math.PI * 2,
        });
      }
      for (let i = 0; i < 5; i++) {
        const cw = Math.ceil(120 + Math.random() * 180);
        const ch = Math.ceil(cw * (0.25 + Math.random() * 0.12));
        const depth = 0.15 + Math.random() * 0.3;
        const texture = this.generateCloudTexture(cw, ch, depth);
        this.particles.push({
          x: Math.random() * w,
          y: 5 + Math.random() * h * 0.55,
          width: cw,
          height: ch,
          speed: 0.08 + Math.random() * 0.2,
          depth,
          texture,
          phase: Math.random() * Math.PI * 2,
        });
      }
      this.particles.sort((a, b) => a.depth - b.depth);
    } else if (this.type === "mist") {
      for (let i = 0; i < 6; i++) {
        const fw = Math.ceil(w * (0.6 + Math.random() * 0.5));
        const fh = Math.ceil(130 + Math.random() * 170);
        const density = 0.4 + Math.random() * 0.3;
        const texture = this.generateFogTexture(fw, fh, density);
        this.particles.push({
          x: Math.random() * w,
          y: h * 0.45 + Math.random() * h * 0.5,
          width: fw,
          height: fh,
          speed: 0.06 + Math.random() * 0.1,
          dir: Math.random() > 0.5 ? 1 : -1,
          depth: 0.7 + Math.random() * 0.3,
          texture,
          phase: Math.random() * Math.PI * 2,
          layer: "ground",
        });
      }
      for (let i = 0; i < 5; i++) {
        const fw = Math.ceil(w * (0.5 + Math.random() * 0.4));
        const fh = Math.ceil(90 + Math.random() * 120);
        const density = 0.25 + Math.random() * 0.2;
        const texture = this.generateFogTexture(fw, fh, density);
        this.particles.push({
          x: Math.random() * w,
          y: h * 0.15 + Math.random() * h * 0.5,
          width: fw,
          height: fh,
          speed: 0.08 + Math.random() * 0.14,
          dir: Math.random() > 0.5 ? 1 : -1,
          depth: 0.4 + Math.random() * 0.3,
          texture,
          phase: Math.random() * Math.PI * 2,
          layer: "mid",
        });
      }
      for (let i = 0; i < 4; i++) {
        const fw = Math.ceil(w * (0.3 + Math.random() * 0.3));
        const fh = Math.ceil(40 + Math.random() * 60);
        const density = 0.12 + Math.random() * 0.12;
        const texture = this.generateFogTexture(fw, fh, density);
        this.particles.push({
          x: Math.random() * w,
          y: Math.random() * h * 0.4,
          width: fw,
          height: fh,
          speed: 0.15 + Math.random() * 0.2,
          dir: Math.random() > 0.5 ? 1 : -1,
          depth: 0.1 + Math.random() * 0.2,
          texture,
          phase: Math.random() * Math.PI * 2,
          layer: "wisp",
        });
      }
    }
  }

  generateBolt() {
    const w = this.canvas.width;
    const h = this.canvas.height;
    const startX = w * 0.15 + Math.random() * w * 0.7;
    const endY = h * 0.35 + Math.random() * h * 0.45;
    const points = [{ x: startX, y: 0 }];
    const branches = [];
    const segments = 8 + Math.floor(Math.random() * 6);
    const stepY = endY / segments;
    let x = startX;
    let y = 0;
    for (let i = 0; i < segments; i++) {
      x += (Math.random() - 0.5) * 100;
      y += stepY;
      points.push({ x, y });
      if (Math.random() < 0.45 && i > 1) {
        const bp = [{ x, y }];
        let bx = x;
        let by = y;
        const side = Math.random() > 0.5 ? 1 : -1;
        const bLen = 2 + Math.floor(Math.random() * 4);
        for (let b = 0; b < bLen; b++) {
          bx += side * (15 + Math.random() * 40);
          by += stepY * (0.3 + Math.random() * 0.4);
          bp.push({ x: bx, y: by });
        }
        branches.push(bp);
      }
    }
    return { points, branches, duration: 12 + Math.floor(Math.random() * 8) };
  }

  drawBolt(opacity) {
    const { ctx } = this;
    const bolt = this.lightningBolt;
    if (!bolt) return;

    const drawPath = (pts, width, color) => {
      ctx.beginPath();
      ctx.lineWidth = width;
      ctx.strokeStyle = color;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      pts.forEach((p, i) =>
        i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)
      );
      ctx.stroke();
    };

    drawPath(bolt.points, 12, `rgba(120, 140, 255, ${opacity * 0.15})`);
    drawPath(bolt.points, 6, `rgba(180, 200, 255, ${opacity * 0.4})`);
    drawPath(bolt.points, 2.5, `rgba(255, 255, 255, ${opacity})`);

    bolt.branches.forEach((branch) => {
      drawPath(branch, 6, `rgba(140, 160, 255, ${opacity * 0.12})`);
      drawPath(branch, 2, `rgba(200, 210, 255, ${opacity * 0.35})`);
      drawPath(branch, 1, `rgba(255, 255, 255, ${opacity * 0.6})`);
    });
  }

  drawStar(x, y, r, opacity) {
    const { ctx } = this;
    const spikes = 4;
    const innerR = r * 0.35;

    ctx.save();
    ctx.shadowBlur = r * 3;
    ctx.shadowColor = `rgba(200, 220, 255, ${opacity * 0.6})`;

    ctx.beginPath();
    for (let i = 0; i < spikes * 2; i++) {
      const angle = (i * Math.PI) / spikes - Math.PI / 2;
      const rad = i % 2 === 0 ? r : innerR;
      const px = x + Math.cos(angle) * rad;
      const py = y + Math.sin(angle) * rad;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
    ctx.fill();
    ctx.restore();
  }

  drawFlake(x, y, r, opacity, rotation) {
    const { ctx } = this;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);
    ctx.strokeStyle = `rgba(255, 255, 255, ${opacity})`;
    ctx.lineWidth = r * 0.12;
    ctx.lineCap = "round";

    for (let i = 0; i < 6; i++) {
      const angle = (i * Math.PI) / 3;
      ctx.save();
      ctx.rotate(angle);

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, -r);
      ctx.stroke();

      const branchY = -r * 0.5;
      const branchLen = r * 0.35;
      ctx.beginPath();
      ctx.moveTo(0, branchY);
      ctx.lineTo(-branchLen * 0.6, branchY - branchLen);
      ctx.moveTo(0, branchY);
      ctx.lineTo(branchLen * 0.6, branchY - branchLen);
      ctx.stroke();

      const branchY2 = -r * 0.75;
      const branchLen2 = r * 0.2;
      ctx.beginPath();
      ctx.moveTo(0, branchY2);
      ctx.lineTo(-branchLen2 * 0.6, branchY2 - branchLen2);
      ctx.moveTo(0, branchY2);
      ctx.lineTo(branchLen2 * 0.6, branchY2 - branchLen2);
      ctx.stroke();

      ctx.restore();
    }

    ctx.restore();
  }

  createNoiseEngine() {
    const perm = new Uint8Array(512);
    for (let i = 0; i < 256; i++) perm[i] = i;
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = perm[i];
      perm[i] = perm[j];
      perm[j] = tmp;
    }
    for (let i = 0; i < 256; i++) perm[i + 256] = perm[i];

    const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
    const lerp = (a, b, t) => a + t * (b - a);
    const grad2 = (hash, x, y) => {
      const h = hash & 3;
      return ((h & 1) === 0 ? x : -x) + ((h & 2) === 0 ? y : -y);
    };

    const noise = (x, y) => {
      const xi = Math.floor(x) & 255;
      const yi = Math.floor(y) & 255;
      const xf = x - Math.floor(x);
      const yf = y - Math.floor(y);
      const u = fade(xf);
      const v = fade(yf);
      const aa = perm[perm[xi] + yi];
      const ab = perm[perm[xi] + yi + 1];
      const ba = perm[perm[xi + 1] + yi];
      const bb = perm[perm[xi + 1] + yi + 1];
      return lerp(
        lerp(grad2(aa, xf, yf), grad2(ba, xf - 1, yf), u),
        lerp(grad2(ab, xf, yf - 1), grad2(bb, xf - 1, yf - 1), u),
        v
      );
    };

    const fbm = (x, y, oct) => {
      let val = 0,
        amp = 1,
        freq = 1,
        max = 0;
      for (let i = 0; i < oct; i++) {
        val += noise(x * freq, y * freq) * amp;
        max += amp;
        amp *= 0.5;
        freq *= 2;
      }
      return val / max;
    };

    return { noise, fbm };
  }

  renderToTexture(sw, sh, outW, outH, pixelFn) {
    const off = document.createElement("canvas");
    off.width = sw;
    off.height = sh;
    const octx = off.getContext("2d");
    const img = octx.createImageData(sw, sh);
    const data = img.data;

    for (let py = 0; py < sh; py++) {
      for (let px = 0; px < sw; px++) {
        const rgba = pixelFn(px, py, sw, sh);
        const idx = (py * sw + px) * 4;
        data[idx] = rgba[0];
        data[idx + 1] = rgba[1];
        data[idx + 2] = rgba[2];
        data[idx + 3] = rgba[3];
      }
    }

    octx.putImageData(img, 0, 0);

    const result = document.createElement("canvas");
    result.width = outW;
    result.height = outH;
    const rctx = result.getContext("2d");
    rctx.imageSmoothingEnabled = true;
    rctx.imageSmoothingQuality = "high";
    rctx.drawImage(off, 0, 0, outW, outH);

    return result;
  }

  generateCloudTexture(cw, ch, depth) {
    const sw = Math.ceil(cw * 0.5);
    const sh = Math.ceil(ch * 0.5);
    const { fbm } = this.createNoiseEngine();

    return this.renderToTexture(sw, sh, cw, ch, (px, py, w, h) => {
      const nx = (px / w - 0.5) * 2;
      const ny = (py / h - 0.5) * 2;

      let shape = Math.max(0, 1 - (nx * nx * 1.1 + ny * ny * 1.4));
      if (ny > 0.1) shape *= Math.max(0, 1 - (ny - 0.1) * 1.8);

      const bump = fbm(px * 0.04, py * 0.035, 3) * 0.5 + 0.5;
      if (ny < 0) shape = Math.min(1, shape + bump * 0.35 * Math.abs(ny));
      shape = Math.max(0, Math.min(1, shape));

      const d1 = fbm(px * 0.022, py * 0.028, 6) * 0.5 + 0.5;
      const d2 = fbm(px * 0.008 + 50, py * 0.01 + 50, 3) * 0.5 + 0.5;
      const detail = d1 * 0.6 + d2 * 0.4;

      let alpha = shape * (0.12 + detail * 0.88);
      let t = Math.max(0, Math.min(1, (alpha - 0.08) / 0.52));
      alpha = t * t * (3 - 2 * t);

      const light = 0.8 + 0.2 * (1 - ny * 0.5);
      const warm = Math.max(0, -ny) * 0.12;

      return [
        Math.min(255, Math.round((215 + 40 * detail + warm * 55) * light)),
        Math.min(255, Math.round((220 + 35 * detail + warm * 25) * light)),
        Math.min(255, Math.round((232 + 23 * detail) * light)),
        Math.round(alpha * 220 * depth),
      ];
    });
  }

  generateFogTexture(fw, fh, density) {
    const sw = Math.ceil(fw * 0.25);
    const sh = Math.ceil(fh * 0.25);
    const { fbm } = this.createNoiseEngine();

    return this.renderToTexture(sw, sh, fw, fh, (px, py, w, h) => {
      const nx = (px / w - 0.5) * 2;
      const ny = (py / h - 0.5) * 2;

      let shape = Math.max(0, 1 - ny * ny * 2.2);
      const edgeX = Math.abs(nx);
      shape *= Math.max(0, 1 - edgeX * edgeX * edgeX * 1.8);

      const n1 = fbm(px * 0.018, py * 0.035, 5) * 0.5 + 0.5;
      const n2 = fbm(px * 0.006 + 80, py * 0.012 + 80, 3) * 0.5 + 0.5;
      const detail = n1 * 0.55 + n2 * 0.45;

      let alpha = shape * (0.15 + detail * 0.85);
      let t = Math.max(0, Math.min(1, (alpha - 0.06) / 0.55));
      alpha = t * t * (3 - 2 * t);

      return [
        Math.min(255, Math.round(205 + 45 * detail)),
        Math.min(255, Math.round(210 + 40 * detail)),
        Math.min(255, Math.round(220 + 30 * detail)),
        Math.round(alpha * 200 * density),
      ];
    });
  }

  animate() {
    const { ctx, canvas, particles, type } = this;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (type === "rain") {
      particles.forEach((p) => {
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x + p.wind * 2, p.y + p.len);
        ctx.strokeStyle = `rgba(180, 210, 240, ${p.opacity})`;
        ctx.lineWidth = 1;
        ctx.stroke();
        p.y += p.speed;
        p.x += p.wind;
        if (p.y > canvas.height) {
          p.y = -p.len;
          p.x = Math.random() * canvas.width * 1.2;
        }
      });
    } else if (type === "thunder") {
      ctx.fillStyle = "rgba(0, 0, 0, 0.03)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p) => {
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x + p.wind * 2.5, p.y + p.len);
        ctx.strokeStyle = `rgba(160, 190, 230, ${p.opacity})`;
        ctx.lineWidth = 1.2;
        ctx.stroke();
        p.y += p.speed;
        p.x += p.wind;
        if (p.y > canvas.height) {
          p.y = -p.len;
          p.x = Math.random() * canvas.width * 1.4;
        }
      });

      if (this.lightningCooldown > 0) this.lightningCooldown--;

      if (
        Math.random() < 0.012 &&
        !this.lightningBolt &&
        this.lightningCooldown <= 0
      ) {
        this.lightningBolt = this.generateBolt();
        this.lightningTimer = this.lightningBolt.duration;
        this.lightningCooldown = 20 + Math.floor(Math.random() * 40);
      }

      if (this.lightningTimer > 0 && this.lightningBolt) {
        const total = this.lightningBolt.duration;
        const progress = 1 - this.lightningTimer / total;

        let flashAlpha;
        if (progress < 0.15) flashAlpha = 0.15;
        else if (progress < 0.25) flashAlpha = 0.05;
        else if (progress < 0.35) flashAlpha = 0.12;
        else flashAlpha = 0.02 * (this.lightningTimer / total);

        ctx.fillStyle = `rgba(200, 210, 255, ${flashAlpha})`;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        let boltOpacity;
        if (progress < 0.2) boltOpacity = 1;
        else if (progress < 0.3) boltOpacity = 0.3;
        else if (progress < 0.4) boltOpacity = 0.9;
        else boltOpacity = Math.max(0, this.lightningTimer / total);

        this.drawBolt(boltOpacity);
        this.lightningTimer--;
        if (this.lightningTimer <= 0) this.lightningBolt = null;
      }
    } else if (type === "snow") {
      const time = Date.now() / 1000;
      particles.forEach((p) => {
        if (p.crystal) {
          p.rotation += p.rotSpeed;
          this.drawFlake(p.x, p.y, p.r, p.opacity, p.rotation);
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity})`;
          ctx.fill();
        }
        p.y += p.speed;
        p.x += Math.sin(time * 0.8 + p.phase) * p.amplitude;
        if (p.y > canvas.height + p.r * 2) {
          p.y = -p.r * 4;
          p.x = Math.random() * canvas.width;
        }
      });
    } else if (type === "stars") {
      const time = Date.now() / 1000;
      particles.forEach((p) => {
        const twinkle = 0.5 + 0.5 * Math.sin(time * p.speed + p.phase);
        const opacity = p.baseOpacity * twinkle;
        if (p.bright) {
          this.drawStar(p.x, p.y, p.r, opacity);
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
          ctx.fill();
        }
      });

      if (this.shootingCooldown > 0) this.shootingCooldown--;

      if (
        Math.random() < 0.004 &&
        this.shootingStars.length < 2 &&
        this.shootingCooldown <= 0
      ) {
        const startX = canvas.width * 0.1 + Math.random() * canvas.width * 0.8;
        const startY = Math.random() * canvas.height * 0.35;
        const angle = Math.PI * 0.15 + Math.random() * Math.PI * 0.2;
        const speed = 6 + Math.random() * 8;
        this.shootingStars.push({
          x: startX,
          y: startY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 1,
          decay: 0.012 + Math.random() * 0.008,
          tail: [],
          size: 1.5 + Math.random() * 1.5,
        });
        this.shootingCooldown = 60 + Math.floor(Math.random() * 120);
      }

      this.shootingStars = this.shootingStars.filter((s) => {
        s.tail.unshift({ x: s.x, y: s.y, life: s.life });
        if (s.tail.length > 25) s.tail.pop();

        s.x += s.vx;
        s.y += s.vy;
        s.life -= s.decay;

        if (s.tail.length > 1) {
          for (let i = s.tail.length - 1; i >= 1; i--) {
            const p0 = s.tail[i];
            const p1 = s.tail[i - 1];
            const t = 1 - i / s.tail.length;
            const alpha = t * t * s.life * 0.8;
            const width = s.size * t;
            ctx.beginPath();
            ctx.moveTo(p0.x, p0.y);
            ctx.lineTo(p1.x, p1.y);
            ctx.strokeStyle = `rgba(220, 235, 255, ${alpha})`;
            ctx.lineWidth = width;
            ctx.lineCap = "round";
            ctx.stroke();
          }

          const glow = s.tail[0];
          ctx.save();
          ctx.shadowBlur = 12;
          ctx.shadowColor = `rgba(180, 210, 255, ${s.life * 0.6})`;
          ctx.beginPath();
          ctx.arc(glow.x, glow.y, s.size * 0.8, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${s.life})`;
          ctx.fill();
          ctx.restore();
        }

        return s.life > 0;
      });
    } else if (type === "sun") {
      const time = Date.now() / 1000;
      particles.forEach((p) => {
        const pulse = 0.5 + 0.5 * Math.sin(time * 0.5 + p.phase);
        const opacity = p.opacity * (0.6 + 0.4 * pulse);
        const r = p.r * (0.8 + 0.2 * pulse);
        ctx.beginPath();
        ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 220, 100, ${opacity})`;
        ctx.fill();
        p.y -= p.speed;
        if (p.y < -p.r * 2) {
          p.y = canvas.height + p.r * 2;
          p.x = Math.random() * canvas.width;
        }
      });
    } else if (type === "cloudy") {
      const time = Date.now() / 12000;
      particles.forEach((p) => {
        const shimmer = 0.92 + 0.08 * Math.sin(time + p.phase);
        ctx.globalAlpha = shimmer;
        ctx.drawImage(p.texture, p.x - p.width / 2, p.y - p.height / 2);
        p.x += p.speed * p.depth;
        p.y += Math.sin(time * 0.4 + p.phase) * 0.015;
        if (p.x > canvas.width + p.width) {
          p.x = -p.width;
          p.y = 10 + Math.random() * canvas.height * 0.5;
        }
      });
      ctx.globalAlpha = 1;
    } else if (type === "mist") {
      const time = Date.now() / 8000;

      const hazeGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
      hazeGrad.addColorStop(0, "rgba(195, 205, 220, 0.04)");
      hazeGrad.addColorStop(0.3, "rgba(195, 205, 220, 0.07)");
      hazeGrad.addColorStop(0.6, "rgba(195, 205, 220, 0.11)");
      hazeGrad.addColorStop(1, "rgba(195, 205, 220, 0.16)");
      ctx.fillStyle = hazeGrad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p) => {
        const breathe = 0.82 + 0.18 * Math.sin(time + p.phase);
        ctx.globalAlpha = breathe;
        ctx.drawImage(p.texture, p.x - p.width / 2, p.y - p.height / 2);
        p.x += p.speed * p.dir;
        p.y += Math.sin(time * 0.35 + p.phase) * 0.06;

        const hw = p.width / 2;
        if (p.dir > 0 && p.x > canvas.width + hw) {
          p.x = -hw;
          p.y += (Math.random() - 0.5) * canvas.height * 0.08;
          p.y = Math.max(0, Math.min(canvas.height - p.height / 2, p.y));
        } else if (p.dir < 0 && p.x < -hw) {
          p.x = canvas.width + hw;
          p.y += (Math.random() - 0.5) * canvas.height * 0.08;
          p.y = Math.max(0, Math.min(canvas.height - p.height / 2, p.y));
        }
      });
      ctx.globalAlpha = 1;

      const topHaze = ctx.createLinearGradient(0, 0, 0, canvas.height * 0.25);
      topHaze.addColorStop(0, "rgba(195, 205, 220, 0.07)");
      topHaze.addColorStop(1, "rgba(195, 205, 220, 0)");
      ctx.fillStyle = topHaze;
      ctx.fillRect(0, 0, canvas.width, canvas.height * 0.25);
    }

    this.animId = requestAnimationFrame(() => this.animate());
  }

  destroy() {
    if (this.animId) {
      cancelAnimationFrame(this.animId);
      this.animId = null;
    }
    this.particles = [];
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }
}

const SOUND_PROFILES = {
  rain: [["rain", 0.4]],
  thunder: [
    ["thunder", 0.5],
    ["rain", 0.25],
  ],
  snow: [
    ["snow", 0.35],
    ["wind", 0.08],
  ],
  mist: [["wind", 0.2]],
  cloudy: [["wind", 0.08]],
  stars: [["night", 0.35]],
  sun: [["day", 0.3]],
};

const SOUND_SOURCES = {
  rain: "sounds/rain.mp3",
  thunder: "sounds/thunder.mp3",
  wind: "sounds/wind.mp3",
  snow: "sounds/snow.mp3",
  night: "sounds/night.mp3",
  day: "sounds/day.mp3",
};

class SoundSystem {
  constructor() {
    this.active = [];
    this.muted = true;
    this.currentType = null;
  }

  createAudio(src, volume) {
    const audio = new Audio(src);
    audio.loop = true;
    audio.volume = this.muted ? 0 : volume;
    audio.preload = "auto";
    audio.targetVolume = volume;
    return audio;
  }

  stopAll() {
    this.active.forEach((a) => {
      a.pause();
      a.currentTime = 0;
      a.src = "";
    });
    this.active = [];
  }

  play(name, volume) {
    const src = SOUND_SOURCES[name];
    if (!src) return;
    const audio = this.createAudio(src, volume);
    this.active.push(audio);
    audio.play().catch(() => {});
  }

  setWeather(type) {
    if (type === this.currentType) return;
    this.currentType = type;
    this.stopAll();

    const profile = SOUND_PROFILES[type];
    if (profile) {
      profile.forEach(([name, vol]) => this.play(name, vol));
    }
  }

  toggleMute() {
    this.muted = !this.muted;
    this.active.forEach((a) => {
      a.volume = this.muted ? 0 : a.targetVolume;
    });
    if (!this.muted && this.active.length === 0 && this.currentType) {
      const type = this.currentType;
      this.currentType = null;
      this.setWeather(type);
    }
  }
}

class WeatherApp {
  constructor() {
    this.cache = new RequestCache();
    this.elements = this.getElements();
    this.particles = new ParticleSystem(document.getElementById("particles"));
    this.sound = new SoundSystem();
    this.currentWeatherMain = null;
    this.currentIconCode = null;
    this.clockInterval = null;
    this.bindEvents();
    this.loadColorMode();
    this.renderSearchHistory();
    this.restoreLastCity();
  }

  getElements() {
    const $ = (id) => document.getElementById(id);
    return {
      cityInput: $("cityInput"),
      searchBtn: $("searchBtn"),
      locationBtn: $("locationBtn"),
      themeToggle: $("themeToggle"),
      soundBtn: $("soundBtn"),
      loading: $("loading"),
      errorBox: $("errorBox"),
      errorMessage: $("errorMessage"),
      mainContent: $("mainContent"),
      cityName: $("cityName"),
      currentDate: $("currentDate"),
      cityTime: $("cityTime"),
      weatherDesc: $("weatherDesc"),
      weatherIcon: $("weatherIcon"),
      currentTemp: $("currentTemp"),
      feelsLike: $("feelsLike"),
      tempRange: $("tempRange"),
      humidity: $("humidity"),
      wind: $("wind"),
      pressure: $("pressure"),
      visibility: $("visibility"),
      sunrise: $("sunrise"),
      sunset: $("sunset"),
      clouds: $("clouds"),
      dewPoint: $("dewPoint"),
      hourlyForecast: $("hourlyForecast"),
      dailyForecast: $("dailyForecast"),
      searchHistory: $("searchHistory"),
      aqiSection: $("aqiSection"),
      aqiContent: $("aqiContent"),
      lastUpdated: $("lastUpdated"),
    };
  }

  bindEvents() {
    this.elements.searchBtn.addEventListener("click", () =>
      this.handleSearch()
    );
    this.elements.cityInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") this.handleSearch();
    });
    this.elements.locationBtn.addEventListener("click", () =>
      this.handleGeolocation()
    );
    this.elements.themeToggle.addEventListener("click", () =>
      this.toggleTheme()
    );

    if (this.elements.soundBtn) {
      this.elements.soundBtn.addEventListener("click", () => {
        this.sound.toggleMute();
        this.elements.soundBtn.classList.toggle("muted", this.sound.muted);
      });
    }

    const debugSelect = document.getElementById("debugWeather");
    if (debugSelect) {
      debugSelect.addEventListener("change", (e) => {
        const entry = DEBUG_WEATHER_MAP[e.target.value];
        if (!entry) return;
        this.particles.type = null;
        this.applyWeatherTheme(entry[0], entry[1]);
      });
    }
  }

  loadColorMode() {
    if (localStorage.getItem("colorMode") === "light") {
      document.body.classList.add("light");
    }
  }

  isLightMode() {
    return document.body.classList.contains("light");
  }

  toggleTheme() {
    document.body.classList.toggle("light");
    localStorage.setItem("colorMode", this.isLightMode() ? "light" : "dark");
  }

  applyWeatherTheme(weatherMain, iconCode) {
    this.currentWeatherMain = weatherMain;
    this.currentIconCode = iconCode;
    const keepLight = this.isLightMode();
    document.body.className = keepLight ? "light" : "";
    const theme = THEME_MAP[weatherMain];
    if (theme) {
      const isNight = iconCode.endsWith("n");
      document.body.classList.add(
        isNight ? `theme-${theme}-night` : `theme-${theme}`
      );
    }
    this.particles.setWeather(weatherMain, iconCode);

    const pType = this.particles.type;
    this.sound.setWeather(pType);
  }

  showState(state) {
    this.elements.loading.classList.remove("active");
    this.elements.errorBox.classList.remove("active");
    this.elements.mainContent.classList.remove("active");

    if (state === "loading") {
      this.elements.loading.classList.add("active");
    } else if (state === "error") {
      this.elements.errorBox.classList.add("active");
    } else if (state === "content") {
      this.elements.mainContent.classList.add("active");
    }
  }

  showError(message) {
    this.elements.errorMessage.textContent = message;
    this.showState("error");
  }

  async fetchJSON(url) {
    const cached = this.cache.get(url);
    if (cached) return cached;

    const response = await fetch(url);
    if (!response.ok) {
      if (response.status === 404) throw new Error("شهر مورد نظر یافت نشد");
      if (response.status === 401) throw new Error("کلید API نامعتبر است");
      throw new Error("خطا در دریافت اطلاعات");
    }
    const data = await response.json();
    this.cache.set(url, data);
    return data;
  }

  getSearchHistory() {
    try {
      return JSON.parse(localStorage.getItem("searchHistory")) || [];
    } catch {
      return [];
    }
  }

  saveSearchHistory(history) {
    localStorage.setItem("searchHistory", JSON.stringify(history));
  }

  addToHistory(city) {
    let history = this.getSearchHistory();
    history = history.filter((c) => c.toLowerCase() !== city.toLowerCase());
    history.unshift(city);
    if (history.length > 5) history = history.slice(0, 5);
    this.saveSearchHistory(history);
    this.renderSearchHistory();
  }

  removeFromHistory(city) {
    const history = this.getSearchHistory().filter((c) => c !== city);
    this.saveSearchHistory(history);
    this.renderSearchHistory();
  }

  renderSearchHistory() {
    const container = this.elements.searchHistory;
    const history = this.getSearchHistory();

    container.innerHTML = history
      .map(
        (city) =>
          `<span class="history-chip" data-city="${city}">${city}<span class="chip-remove">\u00D7</span></span>`
      )
      .join("");

    container.onclick = (e) => {
      const chip = e.target.closest(".history-chip");
      if (!chip) return;
      const city = chip.dataset.city;
      if (e.target.classList.contains("chip-remove")) {
        this.removeFromHistory(city);
      } else {
        this.elements.cityInput.value = city;
        this.fetchWeatherByCity(city);
      }
    };
  }

  startClock(timezone) {
    if (this.clockInterval) clearInterval(this.clockInterval);
    this.updateClock(timezone);
    this.clockInterval = setInterval(() => this.updateClock(timezone), 30000);
  }

  updateClock(timezone) {
    const now = Math.floor(Date.now() / 1000);
    const localTime = new Date((now + timezone) * 1000);
    const h = localTime.getUTCHours().toString().padStart(2, "0");
    const m = localTime.getUTCMinutes().toString().padStart(2, "0");
    this.elements.cityTime.textContent = `\u200F${toPersianNumber(
      h
    )}:${toPersianNumber(m)} ساعت محلی`;
  }

  renderCurrentWeather(data) {
    const {
      main,
      weather,
      wind,
      visibility: vis,
      sys,
      name,
      dt,
      timezone,
      clouds,
    } = data;
    const desc = WEATHER_FA[weather[0].id] || weather[0].description;

    this.elements.cityName.textContent = `${name}، ${sys.country}`;
    this.elements.currentDate.textContent = formatPersianDate(dt, timezone);
    this.elements.weatherDesc.textContent = desc;
    this.elements.weatherIcon.src = getIconUrl(weather[0].icon, 4);
    this.elements.weatherIcon.alt = desc;
    this.elements.currentTemp.textContent = `\u200F${toPersianNumber(
      Math.round(main.temp)
    )}°`;
    this.elements.feelsLike.textContent = `دمای حسی ${toPersianNumber(
      Math.round(main.feels_like)
    )} درجه`;
    this.elements.tempRange.textContent = `بیشینه ${toPersianNumber(
      Math.round(main.temp_max)
    )} · کمینه ${toPersianNumber(Math.round(main.temp_min))} درجه`;
    this.elements.humidity.textContent = `\u200F${toPersianNumber(
      main.humidity
    )}٪`;
    this.elements.wind.textContent = `${toPersianNumber(
      Math.round(wind.speed * 3.6)
    )} ک.ب.س · ${getWindDirection(wind.deg)}`;
    this.elements.pressure.textContent = `${toPersianNumber(
      main.pressure
    )} هکتوپاسکال`;
    this.elements.visibility.textContent =
      vis >= 1000
        ? `${toPersianNumber(Math.round(vis / 1000))} کیلومتر`
        : `${toPersianNumber(vis)} متر`;
    this.elements.sunrise.textContent = formatTime(sys.sunrise, timezone);
    this.elements.sunset.textContent = formatTime(sys.sunset, timezone);
    this.elements.clouds.textContent = `\u200F${toPersianNumber(clouds.all)}٪`;
    this.elements.dewPoint.textContent = `${toPersianNumber(
      calcDewPoint(main.temp, main.humidity)
    )}°`;

    const now = new Date();
    this.elements.lastUpdated.textContent = `آخرین بروزرسانی: ${toPersianNumber(
      now.getHours().toString().padStart(2, "0")
    )}:${toPersianNumber(now.getMinutes().toString().padStart(2, "0"))}`;

    this.startClock(timezone);
    this.applyWeatherTheme(weather[0].main, weather[0].icon);
  }

  renderHourlyForecast(forecastList, timezone) {
    this.elements.hourlyForecast.innerHTML = forecastList
      .slice(0, 8)
      .map((item, i) => {
        const time = i === 0 ? "الان" : formatTime(item.dt, timezone);
        const desc =
          WEATHER_FA[item.weather[0].id] || item.weather[0].description;
        return (
          `<div class="hourly-card${i === 0 ? " now" : ""}">` +
          `<span class="hourly-time">${time}</span>` +
          `<img class="hourly-icon" src="${getIconUrl(
            item.weather[0].icon
          )}" alt="${desc}">` +
          `<span class="hourly-temp">\u200F${toPersianNumber(
            Math.round(item.main.temp)
          )}°</span>` +
          `</div>`
        );
      })
      .join("");
  }

  renderDailyForecast(forecastList) {
    const dailyMap = new Map();

    forecastList.forEach((item) => {
      const dateKey = new Date(item.dt * 1000).toDateString();
      if (!dailyMap.has(dateKey)) {
        dailyMap.set(dateKey, { items: [], min: Infinity, max: -Infinity });
      }
      const entry = dailyMap.get(dateKey);
      entry.items.push(item);
      entry.min = Math.min(entry.min, item.main.temp_min);
      entry.max = Math.max(entry.max, item.main.temp_max);
    });

    const today = new Date().toDateString();
    const days = [...dailyMap.entries()]
      .filter(([key]) => key !== today)
      .slice(0, 5);

    if (days.length === 0) {
      this.elements.dailyForecast.innerHTML = "";
      return;
    }

    let globalMin = Infinity;
    let globalMax = -Infinity;
    days.forEach(([, d]) => {
      globalMin = Math.min(globalMin, d.min);
      globalMax = Math.max(globalMax, d.max);
    });
    const globalRange = globalMax - globalMin || 1;

    this.elements.dailyForecast.innerHTML = days
      .map(([, dayData]) => {
        const midItem = dayData.items[Math.floor(dayData.items.length / 2)];
        const dayName = new Date(midItem.dt * 1000).toLocaleDateString(
          "fa-IR",
          { weekday: "long" }
        );
        const desc =
          WEATHER_FA[midItem.weather[0].id] || midItem.weather[0].description;
        const barLeft = ((dayData.min - globalMin) / globalRange) * 100;
        const barWidth = Math.max(
          ((dayData.max - dayData.min) / globalRange) * 100,
          4
        );
        const colorStart = tempToColor(dayData.min, globalMin, globalMax);
        const colorEnd = tempToColor(dayData.max, globalMin, globalMax);

        return (
          `<div class="daily-row">` +
          `<span class="daily-day">${dayName}</span>` +
          `<div class="daily-icon-box">` +
          `<img class="daily-icon" src="${getIconUrl(
            midItem.weather[0].icon
          )}" alt="">` +
          `<span class="daily-desc">${desc}</span>` +
          `</div>` +
          `<div class="daily-temp-bar-wrap">` +
          `<span class="daily-low">\u200F${toPersianNumber(
            Math.round(dayData.min)
          )}°</span>` +
          `<div class="daily-temp-bar">` +
          `<div class="daily-temp-fill" style="left:${barLeft}%;width:${barWidth}%;background:linear-gradient(to right,${colorStart},${colorEnd})"></div>` +
          `</div>` +
          `<span class="daily-high">\u200F${toPersianNumber(
            Math.round(dayData.max)
          )}°</span>` +
          `</div>` +
          `</div>`
        );
      })
      .join("");
  }

  async renderAQI(lat, lon) {
    try {
      const url = `${BASE_URL}/air_pollution?lat=${lat}&lon=${lon}&appid=${API_KEY}`;
      const data = await this.fetchJSON(url);
      const aqi = data.list[0].main.aqi;
      const components = data.list[0].components;

      const label = AQI_LABELS[aqi] || "";
      const cssClass = AQI_CLASSES[aqi] || "";
      const markerPos = ((aqi - 1) / 4) * 100;

      const pollutants = [
        ["PM2.5", components.pm2_5],
        ["PM10", components.pm10],
        ["O₃", components.o3],
        ["NO₂", components.no2],
        ["SO₂", components.so2],
        ["CO", components.co],
      ];

      this.elements.aqiContent.innerHTML =
        `<div class="aqi-header">` +
        `<span class="aqi-badge ${cssClass}">${label}</span>` +
        `<span class="aqi-index">شاخص ${toPersianNumber(aqi)} از ۵</span>` +
        `</div>` +
        `<div class="aqi-bar-container">` +
        `<div class="aqi-bar-marker" style="left:${markerPos}%"></div>` +
        `</div>` +
        `<div class="aqi-pollutants">` +
        pollutants
          .map(
            ([name, val]) =>
              `<div class="aqi-pollutant"><span class="aqi-pollutant-name">${name}</span><span class="aqi-pollutant-value">${toPersianNumber(
                Math.round(val * 10) / 10
              )}</span></div>`
          )
          .join("") +
        `</div>`;

      this.elements.aqiSection.classList.add("active");
    } catch {
      this.elements.aqiSection.classList.remove("active");
    }
  }

  async loadWeather(weatherData) {
    const { lat, lon } = weatherData.coord;
    const forecastUrl = `${BASE_URL}/forecast?lat=${lat}&lon=${lon}&units=metric&lang=fa&appid=${API_KEY}`;
    const forecastData = await this.fetchJSON(forecastUrl);

    this.renderCurrentWeather(weatherData);
    this.renderHourlyForecast(forecastData.list, weatherData.timezone);
    this.renderDailyForecast(forecastData.list);
    this.showState("content");

    this.renderAQI(lat, lon);
    this.addToHistory(weatherData.name);
    localStorage.setItem("lastCity", weatherData.name);
  }

  async fetchWeatherByCity(city) {
    this.showState("loading");
    try {
      const url = `${BASE_URL}/weather?q=${encodeURIComponent(
        city
      )}&units=metric&lang=fa&appid=${API_KEY}`;
      await this.loadWeather(await this.fetchJSON(url));
    } catch (error) {
      this.showError(error.message);
    }
  }

  async fetchWeatherByCoords(lat, lon) {
    this.showState("loading");
    try {
      const url = `${BASE_URL}/weather?lat=${lat}&lon=${lon}&units=metric&lang=fa&appid=${API_KEY}`;
      await this.loadWeather(await this.fetchJSON(url));
    } catch (error) {
      this.showError(error.message);
    }
  }

  handleSearch() {
    const city = this.elements.cityInput.value.trim();
    if (!city) {
      this.showError("لطفاً نام شهر را وارد کنید");
      return;
    }
    this.fetchWeatherByCity(city);
  }

  handleGeolocation() {
    if (!navigator.geolocation) {
      this.showError("مرورگر شما از موقعیت‌یابی پشتیبانی نمی‌کند");
      return;
    }

    if (!window.isSecureContext) {
      this.showError("موقعیت‌یابی فقط روی HTTPS کار می‌کند");
      return;
    }

    this.showState("loading");

    navigator.geolocation.getCurrentPosition(
      (position) => {
        this.fetchWeatherByCoords(
          position.coords.latitude,
          position.coords.longitude
        );
      },
      (error) => {
        this.showError(GEO_ERRORS[error.code] || "خطا در دریافت موقعیت");
      },
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 300000 }
    );
  }

  restoreLastCity() {
    const lastCity = localStorage.getItem("lastCity");
    if (lastCity) {
      this.elements.cityInput.value = lastCity;
      this.fetchWeatherByCity(lastCity);
    }
  }
}

new WeatherApp();
